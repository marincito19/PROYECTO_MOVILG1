package cl.duoc.cimuc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. Conectar las variables de Kotlin con las vistas del XML por su ID
        val btnSearch = findViewById<ImageButton>(R.id.btnSearchHeader)
        val btnProyectos = findViewById<Button>(R.id.btnCategoryProyectos)
        val btnCapacidades = findViewById<Button>(R.id.btnCategoryCapacidades)
        val btnIntegrantes = findViewById<Button>(R.id.btnCategoryIntegrantes)
        val btnPublicaciones = findViewById<Button>(R.id.btnCategoryPublicaciones)
        val btnExplorarRuta = findViewById<Button>(R.id.btnExplorarRuta)

        // 2. Configurar acciones de clic para Búsqueda y Categorías
        btnSearch.setOnClickListener {
            navegarABusqueda(categoriaFiltro = "TODOS")
        }

        btnProyectos.setOnClickListener {
            navegarABusqueda(categoriaFiltro = "PROYECTO")
        }

        btnCapacidades.setOnClickListener {
            navegarABusqueda(categoriaFiltro = "CAPACIDAD")
        }

        btnIntegrantes.setOnClickListener {
            navegarABusqueda(categoriaFiltro = "INTEGRANTE")
        }

        btnPublicaciones.setOnClickListener {
            navegarABusqueda(categoriaFiltro = "PUBLICACION")
        }

        // 3. Acción para el botón Ruta de Innovación
        btnExplorarRuta.setOnClickListener {
            Toast.makeText(this, "Navegando a la Ruta de Innovación", Toast.LENGTH_SHORT).show()
            // Próximo paso: Abrir la pantalla de la Ruta
        }
    }

    // Función auxiliar reutilizable para abrir la Pantalla 2 (Búsqueda)
    private fun navegarABusqueda(categoriaFiltro: String) {
        // Por ahora mostraremos un mensaje de confirmación mientras creamos la Pantalla 2
        Toast.makeText(this, "Filtro seleccionado: $categoriaFiltro", Toast.LENGTH_SHORT).show()

        /*
        // Descomentaremos esto en el siguiente paso cuando creemos SearchActivity:
        val intent = Intent(this, SearchActivity::class.java).apply {
            putExtra("EXTRA_CATEGORIA", categoriaFiltro)
        }
        startActivity(intent)
        */
    }
}